# Briller palette mockups

One homepage concept and one mobile project/advice screen in two colour directions:

- 01 Graphite & Chalk
- 03 Porcelain & Ink Blue

These are visual concepts, not screenshots of the released app. The live website and app have not been changed. Existing room imagery and the official Briller logo are used without changing their source pixels.

## Interactive preview
Open mockups.html in a browser. It is self-contained, with embedded fonts and images. Switch palettes and website/app views in the top study bar. Before/after dividers, Smart Sparks, budget choices and mobile project tabs work in the prototype.

The technical advice examples use the website’s existing room-specific advice. The prototype does not generate redesigns, save projects or provide a product catalogue. Links to Briller open the real website/app.

## Exports
website-01-full.png and website-03-full.png: full homepage.
website-01-desktop.png and website-03-desktop.png: desktop hero view.
app-01.png and app-03.png: full mobile project screen.
website-comparison.png and app-comparison.png: side-by-side comparisons.

The same layout, typography and images are used in both directions.
