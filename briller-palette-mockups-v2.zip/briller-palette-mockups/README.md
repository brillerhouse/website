# Briller palette mockups — navigation update

Extract the whole ZIP and open **START-HERE.html** in Chrome, Safari, Firefox or Edge.

Four independent HTML pages are included:
- website-01.html — Graphite & Chalk homepage
- website-03.html — Porcelain & Ink Blue homepage
- app-01.html — Graphite & Chalk app
- app-03.html — Porcelain & Ink Blue app

The top switches are ordinary links and work without JavaScript. All images and fonts are embedded. Keep the HTML files together so the links can navigate between them. mockups.html remains an alias of the first website page.

Sliders, Smart Sparks, budget options and mobile tabs need JavaScript. File previews can block JavaScript or navigation; open the extracted HTML in a browser. PNG files are static images with no interactive controls.

These are visual concepts. No live website or app files were changed or deployed.
