#!/usr/bin/env python3
import argparse
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

class Handler(SimpleHTTPRequestHandler):
    def do_GET(self):
        path = urlsplit(self.path).path
        if path == '/':
            self.send_response(302)
            self.send_header('Location', '/en/compare/')
            self.end_headers()
        elif path.startswith(('/en/', '/uk/')) and not path.startswith(('/en/compare/', '/uk/compare/')) and path not in ('/en/compare', '/uk/compare'):
            self.send_response(302)
            self.send_header('Location', 'https://briller.house' + self.path)
            self.end_headers()
        else:
            super().do_GET()

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='View the Briller comparison archive locally.')
    parser.add_argument('--port', type=int, default=8040)
    options = parser.parse_args()
    handler = partial(Handler, directory=str(Path(__file__).resolve().parent / 'site'))
    server = ThreadingHTTPServer(('127.0.0.1', options.port), handler)
    print(f'English: http://localhost:{options.port}/en/compare/', flush=True)
    print(f'Українська: http://localhost:{options.port}/uk/compare/', flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.server_close()
