# Briller — усі сторінки Compare / Порівняння

20 готових HTML-сторінок: по одному огляду та дев'ять порівнянь EN/UK.
Версія вмісту сайту: 8073c4c251a60259857a25086724df316b53c5ed

## Перегляд

Розпакуйте ZIP, відкрийте термінал у його папці й запустіть:

    python3 serve.py --port 8040

Англійська: http://localhost:8040/en/compare/
Українська: http://localhost:8040/uk/compare/

Для іншого порту змініть 8040 у команді й адресі браузера.
Зупинка: Ctrl+C лише в терміналі цього архіву.
Запускайте через локальний сервер: відкриття HTML через file:// не підтримує
абсолютні шляхи до стилів і скриптів. Node.js та npm для перегляду не потрібні.

## Що включено

- site/: готові сторінки, локальні стилі, скрипти, шрифти й зображення.
- source/: дані й основні вихідні файли розділу порівнянь для редагування;
  це витяг з проєкту, а не повний самостійний Next.js-проєкт.
- manifest.json: перелік сторінок, версія та SHA-256 файлів.
- serve.py: локальний сервер на 127.0.0.1.

Порівняння, FAQ, таблиці та перемикання мови доступні локально.
Інші розділи сайту не включено: serve.py перенаправляє їхні посилання на
https://briller.house. Зовнішні посилання та геолокація потребують мережі.
Усі сторінки експорту мають preview noindex; canonical залишається briller.house.

## Сторінки

- /en/compare/
- /en/compare/interior-ai/
- /en/compare/reimaginehome/
- /en/compare/roomgpt/
- /en/compare/homedesigns-ai/
- /en/compare/remodel-ai/
- /en/compare/planner-5d/
- /en/compare/homestyler/
- /en/compare/foyr-neo/
- /en/compare/spacely-ai/
- /uk/compare/
- /uk/compare/interior-ai/
- /uk/compare/reimaginehome/
- /uk/compare/roomgpt/
- /uk/compare/homedesigns-ai/
- /uk/compare/remodel-ai/
- /uk/compare/planner-5d/
- /uk/compare/homestyler/
- /uk/compare/foyr-neo/
- /uk/compare/spacely-ai/
